## intent:apply_leave
- please apply leave for 2 days
- apply a leave for me for 1 day
- can you please apply a leave for next two days from this date
- i want to apply a leave starting 20th of this month
- help me apply a leave for the coming monday
- please plan for a leave for this date
- am planning to take leave on next monday so request for it

## intent:general_query
- how
- why
- what
- when
- where